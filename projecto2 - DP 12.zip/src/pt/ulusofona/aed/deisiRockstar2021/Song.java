package pt.ulusofona.aed.deisiRockstar2021;


public class Song {
    String ID;
    String Titulo;
    Artista[] Artistas;
    int AnoLancamento;
    int duracaoDoTema;
    Boolean letraExplicita;
    int popularidade;
    double dancabilidade;
    double vivacidade;
    double volumeMedio;

    Song(String ID, String Titulo, Artista[] Artista, int AnoLancamento, int duracaoDoTema, boolean letraExplicita,
         int popularidade, double dancabilidade, double vivacidade, double volumeMedio){

        this.ID = ID;
        this.Titulo = Titulo;
        this.Artistas = Artista;
        this.AnoLancamento = AnoLancamento;
        this.duracaoDoTema = duracaoDoTema;
        this.letraExplicita = letraExplicita;
        this.popularidade = popularidade;
        this.dancabilidade = dancabilidade;
        this.vivacidade = vivacidade;
        this.volumeMedio = volumeMedio;
    }
    Song() {

    }

    public String toString(){

        return ID+" | "+ Titulo +" | "+ AnoLancamento;
    }


}
