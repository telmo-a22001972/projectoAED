
package pt.ulusofona.aed.deisiRockstar2021;
import java.io.IOException;
import java.util.Objects;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

public class Main {
    public static ArrayList < Song > teste6 = new ArrayList < > ();
    public static ArrayList < Song > getSongsArray = new ArrayList < > ();
    public static ArrayList < Artista > testeSongArtists = new ArrayList < > ();
    public static ArrayList < Artista > testeSongArtistsFinal = new ArrayList < > ();
    public static ArrayList < Song > testeSongDetails = new ArrayList < Song > ();
    public static ArrayList < Song > testeSongDetailsFinal = new ArrayList < Song > ();
    public static ParseInfo parseInfoSongsTxT = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsArtistsTxT = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsDetailsTxT = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsTxTFinal = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsArtistsTxTFinal = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsDetailsTxTFinal = new ParseInfo(0, 0);

    public static void main(String[] args) throws IOException {
        ArrayList < Song > teste7 = new ArrayList < Song > ();
        loadFiles();

        teste7 = getSongs();
        ParseInfo teste8 = getParseInfo("songs.txt");
        System.out.println("\n----------------------TESTE DO MAIN----------------------");
        //System.out.println(teste7.toString());
        //System.out.println(teste8.toString());
        //System.out.println(getSongsArray.size());
        //System.out.println(parseInfoSongsTxTFinal.toString());

    }

    public static void loadFiles() throws IOException {
        //Aqui lê-se o ficheiro songs.txt
        //System.out.println("----------------------LEITURA DO FICHEIRO songs.txt------------");
        String nomeFicheiro = "songs.txt";
        try {
            File ficheiro = new File(nomeFicheiro);
            FileInputStream fis = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis);
            while (leitorFicheiro.hasNextLine()) {
                String linha = leitorFicheiro.nextLine();
                String[] dados = linha.split("@");
                String[] dadosFinais = new String[dados.length];

                if (dados.length != 3) {
                    parseInfoSongsTxT.numLinhasIgnored += 1;
                    continue;
                }

                for (int count = 0; count < dados.length; count++ ) {
                    dadosFinais[count] = dados[count].trim();
                    if (dadosFinais[count].isEmpty()){
                        parseInfoSongsTxT.numLinhasIgnored += 1;

                    }
                }

                String idTemaMusical = dadosFinais[0];
                String nome = dadosFinais[1];


                int anoLancamento = Integer.parseInt(dadosFinais[2]);
                parseInfoSongsTxT.numLinhasOk += 1;

                Song song = new Song(idTemaMusical, nome, null, anoLancamento, 0, false, 0, 0, 0, 0);
                teste6.add(song);
            }
            leitorFicheiro.close();
            getSongsArray = (ArrayList < Song >) teste6.clone();
            teste6.clear();
            parseInfoSongsTxTFinal = new ParseInfo(parseInfoSongsTxT);
            parseInfoSongsTxT.reset();
            //System.out.println(parseInfoSongsTxTFinal.toString());

        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + nomeFicheiro + " nao foi encontrado.";
            System.out.println(mensagem);
        }
        //System.out.println(teste6.toString());
        //System.out.println("Ok: " + parseInfoSongsTxT.num_Linhas_Ok + ", Ignored: " + parseInfoSongsTxT.num_Linhas_Ignored + "\n");
        //System.out.println("----------------------LEITURA DO FICHEIRO song_artists.txt------------");
        //Aqui é lido o ficheiro song_artists.txt, mas falta ver se é preciso separar vários artistas com o mesmo ID para posições diferentes no ArrayList
        String nomeFicheiro2 = "song_artists.txt";
        try {
            File song_artists = new File(nomeFicheiro2);
            FileInputStream fis2 = new FileInputStream(song_artists);
            Scanner leitorFicheiro2 = new Scanner(fis2);
            while (leitorFicheiro2.hasNextLine()) {
                String linha = leitorFicheiro2.nextLine();
                String[] dados = linha.split("@");
                String[] dadosFinais = new String[dados.length];

                if (dados.length != 2) {
                    parseInfoSongsArtistsTxT.numLinhasIgnored += 1;
                    continue;
                }
                int count;

                for (count = 0; count < 2; count++ ) {
                    dadosFinais[count] = dados[count].trim();
                }

                String idTemaMusical = dadosFinais[0];
                String artista = dadosFinais[1];
                if (idTemaMusical.isEmpty() && artista.isEmpty()){
                    parseInfoSongsArtistsTxT.numLinhasIgnored += 1;
                    continue;
                }
                if (idTemaMusical.isEmpty()){
                    parseInfoSongsArtistsTxT.numLinhasIgnored += 1;
                    continue;
                }


                parseInfoSongsArtistsTxT.numLinhasOk += 1;

                Artista artista2 = new Artista(idTemaMusical, artista);
                testeSongArtists.add(artista2);
            }
            leitorFicheiro2.close();
            //System.out.println(testeSongArtists.size());
            testeSongArtistsFinal = (ArrayList < Artista>) testeSongArtists.clone();
            testeSongArtists.clear();
            parseInfoSongsArtistsTxTFinal = new ParseInfo(parseInfoSongsArtistsTxT);
            parseInfoSongsArtistsTxT.reset();
            //System.out.println(parseInfoSongsArtistsTxTFinal.toString());

        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + nomeFicheiro2 + " não foi encontrado.";
            //System.out.println(mensagem);
        }
        //System.out.println(testeSongArtists.toString());
        //System.out.println("Ok: " + parseInfoSongsArtistsTxT.num_Linhas_Ok + ", Ignored: " + parseInfoSongsArtistsTxT.num_Linhas_Ignored + "\n");
        System.out.println("----------------------LEITURA DO FICHEIRO song_details.txt------------");
        //Aqui lê-se o ficheiro song_details.txt
        boolean letra = false;
        String nomeFicheiro3 = "song_details.txt";
        try {
            File song_details = new File(nomeFicheiro3);
            FileInputStream fis3 = new FileInputStream(song_details);
            Scanner leitorFicheiro3 = new Scanner(fis3);
            while (leitorFicheiro3.hasNextLine()) {
                String linha = leitorFicheiro3.nextLine();
                String[] dados = linha.split("@");
                String[] dadosFinais = new String[dados.length];
                if (dados.length != 7) {
                    parseInfoSongsDetailsTxT.numLinhasIgnored += 1;
                    continue;
                }
                for (int count = 0; count < dados.length; count++ ) {
                    dadosFinais[count] = dados[count].trim();
                    if (dadosFinais[count].isEmpty()){
                        parseInfoSongsTxT.numLinhasIgnored += 1;
                    }
                }

                parseInfoSongsDetailsTxT.numLinhasOk += 1;
                String idTemaMusical = dadosFinais[0];
                //System.out.println(idTemaMusical);
                int duracao = Integer.parseInt(dadosFinais[1]);
                //System.out.println(duracao);
                int letraExplicita = Integer.parseInt(dadosFinais[2]);
                //System.out.println(letraExplicita);
                if (letraExplicita == 0) {
                    letra = false;
                } else {
                    letra = true;
                }
                //System.out.println(letra);
                int populariedade = Integer.parseInt(dadosFinais[3]);
                //System.out.println(populariedade);
                double dancabilidade = Double.parseDouble(dadosFinais[4]);
                //System.out.println(dancabilidade);
                double vivacidade = Double.parseDouble(dadosFinais[5]);
                //System.out.println(vivacidade);
                double volumeMedio = Double.parseDouble(dadosFinais[6]);
                //System.out.println(volumeMedio);
                Song song = new Song(idTemaMusical, null, null, 0, duracao, letra, populariedade, dancabilidade, vivacidade, volumeMedio);
                testeSongDetails.add(song);
            }
            leitorFicheiro3.close();
            testeSongDetailsFinal = (ArrayList < Song >) testeSongDetails.clone();
            testeSongDetails.clear();
            //System.out.println(testeSongDetailsFinal.size());
            parseInfoSongsDetailsTxTFinal = new ParseInfo(parseInfoSongsDetailsTxT);
            //System.out.println(parseInfoSongsDetailsTxTFinal.toString());
            parseInfoSongsDetailsTxT.reset();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + nomeFicheiro3 + " não foi encontrado.";
            //System.out.println(mensagem);
        }
        System.out.println("Ok: " + parseInfoSongsDetailsTxTFinal.numLinhasOk + ", Ignored: " + parseInfoSongsDetailsTxTFinal.numLinhasIgnored);
    }

    public static ArrayList < Song > getSongs() {
        return getSongsArray;
    }

    public static ParseInfo getParseInfo(String fileName) {
        if (Objects.equals(fileName, "songs.txt")) {
            return parseInfoSongsTxTFinal;
        }
        if (Objects.equals(fileName, "song_artists.txt")) {
            return parseInfoSongsArtistsTxTFinal;
        }
        if (Objects.equals(fileName, "song_details.txt")) {
            return parseInfoSongsDetailsTxTFinal;
        }
        return null;
    }
}