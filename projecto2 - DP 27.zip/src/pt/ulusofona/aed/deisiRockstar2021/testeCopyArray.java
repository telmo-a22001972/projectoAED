package pt.ulusofona.aed.deisiRockstar2021;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class testeCopyArray {
    public static void main(String[] args) {
        String dados[];
        String teste = "     0nxvFG50rGXkiGQqOO2MHr @ Be Alright @ 2012";
        String testeTrim = teste.trim();
        System.out.println(teste);
        System.out.println(testeTrim);
        teste.split("@");

    }
}
