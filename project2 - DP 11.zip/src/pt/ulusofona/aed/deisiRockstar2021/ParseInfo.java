package pt.ulusofona.aed.deisiRockstar2021;

public class ParseInfo {
    int NUM_LINHAS_OK;
    int NUM_LINHAS_IGNORED;

    ParseInfo(int NUM_LINHAS_OK, int NUM_LINHAS_IGNORED) {
        this.NUM_LINHAS_OK = NUM_LINHAS_OK;
        this.NUM_LINHAS_IGNORED = NUM_LINHAS_IGNORED;
    }
    ParseInfo() {

    }

    public String toString() {
        return "OK: "+NUM_LINHAS_OK+", Ingnored: "+NUM_LINHAS_IGNORED;
    }
}
