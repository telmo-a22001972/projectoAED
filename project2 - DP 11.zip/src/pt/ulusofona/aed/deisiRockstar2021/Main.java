package pt.ulusofona.aed.deisiRockstar2021;



import org.junit.Assert;
import org.junit.Test;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;


public class Main {
    public static ArrayList<Song> teste6 = new ArrayList<Song>();
    public static ArrayList<Artista> testeSongArtists = new ArrayList<Artista>();
    public static ParseInfo parseInfoSongsTxT = new ParseInfo(0,0);
    public static ParseInfo parseInfoSongsArtistsTxT = new ParseInfo(0,0);
    public static ParseInfo parseInfoSongsDetailsTxT = new ParseInfo(0,0);

    @Test
    public void testSongToString2Musicas() throws IOException {
       Song song1 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
       //Song song2 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
       //ArrayList<Song> testeSongs = new ArrayList<Song>();
       //testeSongs.add(song1);
       //testeSongs.add(song2);
       //String resultadoReal = testeSongs.toString();
       //String resultadoEsperado = "[1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979, 1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979]";
       Assert.assertEquals("1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979",song1.toString());
    }
    @Test
    public void testSongToString3Musicas() throws IOException {
        //Song song1 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
        Song song2 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottles",null,1979,0,false,0,0,0,0);
        //Song song3 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
        //ArrayList<Song> testeSongs = new ArrayList<Song>();
        //testeSongs.add(song1);
        //testeSongs.add(song2);
        //testeSongs.add(song3);
        //String resultadoReal = testeSongs.toString();
        //String resultadoEsperado = "[1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979, 1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979, 1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979]";
        Assert.assertEquals("1oYYd2gnWZYrt89EBXdFiO | Message In A Bottles | 1979",song2.toString());

    }


    public static void main(String[] args) throws IOException {
        //Song teste = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,2,false,1,1,1,1);
        //System.out.println(teste.toString());
        //ParseInfo teste2 = new ParseInfo(341, 5);
        //System.out.println(teste2.toString());
        loadFiles();
        System.out.println("\n");
        System.out.println(getParseInfo("C:/Users/telmo/IdeaProjects/projeto2/src/pt/ulusofona/aed/deisiRockstar2021/songs.txt"));

    }


    public static void loadFiles() throws IOException {
        int songs_num_lin_not_count=0;
        int songs_num_lin_count=0;
        int songs_artists_num_lin_not_count=0;
        int songs_artists_num_lin_count=0;
        int songs_details_num_lin_not_count=0;
        int songs_details_num_lin_count=0;
        //Aqui lê-se o ficheiro songs.txt, mas ainda falsa fazer com que não conte as linhas com menos ou mais que 3 partes.
        System.out.println("----------------------LEITURA DO FICHEIRO songs.txt------------");
        String nomeFicheiro = "C:/Users/telmo/IdeaProjects/projeto2/src/pt/ulusofona/aed/deisiRockstar2021/songs.txt";
        try {
            File ficheiro = new File(nomeFicheiro);
            FileInputStream fis = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis);

            while(leitorFicheiro.hasNextLine()) {
                String linha = leitorFicheiro.nextLine();

                String dados[] = linha.split("@");
                if (dados.length !=3){
                    songs_num_lin_not_count+=1;
                    parseInfoSongsTxT.NUM_LINHAS_IGNORED += 1;
                    continue;
                }
                songs_num_lin_count+=1;
                parseInfoSongsTxT.NUM_LINHAS_OK += 1;
                String idTemaMusical = dados[0];

                String nome = dados[1];

                int anoLancamento = Integer.parseInt(dados[2]);

                Song song = new Song(idTemaMusical, nome, null, anoLancamento, 0, false, 0, 0, 0, 0);
                teste6.add(song);

            }
            leitorFicheiro.close();
        }
        catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro "+nomeFicheiro+" nao foi encontrado.";
            System.out.println(mensagem);
        }
        System.out.println(teste6.toString());
        System.out.println("Ok: "+songs_num_lin_count+", Ignored: "+songs_num_lin_not_count+"\n");


        System.out.println("----------------------LEITURA DO FICHEIRO song_artists.txt------------");
        //Aqui é lido o ficheiro song_artists.txt, mas falta ver se é preciso separar vários artistas com o mesmo ID para posições diferentes no ArrayList
        //E falta caso a linha tenham menos ou mais que 2 componentes.

        String nomeFicheiro2 = "C:/Users/telmo/IdeaProjects/projeto2/src/pt/ulusofona/aed/deisiRockstar2021/song_artists.txt";
        try {
            File song_artists = new File(nomeFicheiro2);
            FileInputStream fis2 = new FileInputStream(song_artists);
            Scanner leitorFicheiro2 = new Scanner(fis2);

            while(leitorFicheiro2.hasNextLine()) {
                String linha = leitorFicheiro2.nextLine();

                String dados[] = linha.split("@");
                if (dados.length !=2){
                    songs_artists_num_lin_not_count+=1;
                    parseInfoSongsArtistsTxT.NUM_LINHAS_IGNORED += 1;
                    continue;
                }
                songs_artists_num_lin_count+=1;
                parseInfoSongsArtistsTxT.NUM_LINHAS_OK += 1;
                String idTemaMusical = dados[0];

                String artista = dados[1];

                Artista artista2 = new Artista(idTemaMusical,artista);

                testeSongArtists.add(artista2);

            }
            leitorFicheiro2.close();
        }
        catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro "+nomeFicheiro2+" não foi encontrado.";
            System.out.println(mensagem);
        }
        System.out.println(testeSongArtists.toString());
        System.out.println("Ok: "+songs_artists_num_lin_count+", Ignored: "+songs_artists_num_lin_not_count+"\n");


        System.out.println("----------------------LEITURA DO FICHEIRO song_details.txt------------");
        //Aqui lê-se o ficheiro song_details.txt , mas falta o clássico se
        boolean letra = false;
        ArrayList<Song> testeSongDetails = new ArrayList<Song>();
        String nomeFicheiro3 = "C:/Users/telmo/IdeaProjects/projeto2/src/pt/ulusofona/aed/deisiRockstar2021/song_details.txt";
        try {
            File song_details = new File(nomeFicheiro3);
            FileInputStream fis3 = new FileInputStream(song_details);
            Scanner leitorFicheiro3 = new Scanner(fis3);

            while (leitorFicheiro3.hasNextLine()) {
                String linha = leitorFicheiro3.nextLine();

                String dados[] = linha.split("@");
                if (dados.length != 7){
                    songs_details_num_lin_not_count+= 1;
                    parseInfoSongsDetailsTxT.NUM_LINHAS_IGNORED += 1;
                    continue;
                }
                songs_details_num_lin_count+= 1;
                parseInfoSongsDetailsTxT.NUM_LINHAS_OK += 1;

                String idTemaMusical = dados[0];
                //System.out.println(idTemaMusical);

                int duracao = Integer.parseInt(dados[1]);
                //System.out.println(duracao);
                int letraExplicita = Integer.parseInt(dados[2]);
                //System.out.println(letraExplicita);
                if (letraExplicita == 0){
                    letra = false;
                } else {
                    letra = true;
                }
                //System.out.println(letra);

                int populariedade = Integer.parseInt(dados[3]);
                //System.out.println(populariedade);
                double dancabilidade = Double.parseDouble(dados[4]);
                //System.out.println(dancabilidade);
                double vivacidade = Double.parseDouble(dados[5]);
                //System.out.println(vivacidade);
                double volumeMedio = Double.parseDouble(dados[6]);
                //System.out.println(volumeMedio);
                Song song = new Song(idTemaMusical,null,null,0,duracao,letra,populariedade,dancabilidade,vivacidade,volumeMedio);
                testeSongDetails.add(song);

            }
            leitorFicheiro3.close();
        }
        catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro "+nomeFicheiro3+" não foi encontrado.";
            System.out.println(mensagem);
        }
        System.out.println("Ok: "+songs_details_num_lin_count+", Ignored: "+songs_details_num_lin_not_count);
    }

    public static ArrayList<Song> getSongs() {
        return teste6;
    }

    public static ParseInfo getParseInfo(String fileName) {
        if (fileName == "C:/Users/telmo/IdeaProjects/projeto2/src/pt/ulusofona/aed/deisiRockstar2021/songs.txt"){
            return parseInfoSongsTxT;
        }
        if (fileName == "C:/Users/telmo/IdeaProjects/projeto2/src/pt/ulusofona/aed/deisiRockstar2021/song_artists.txt"){
            return parseInfoSongsArtistsTxT;
        }
        if (fileName == "C:/Users/telmo/IdeaProjects/projeto2/src/pt/ulusofona/aed/deisiRockstar2021/song_details.txt") {
            return parseInfoSongsDetailsTxT;
        }


        return null;
    }


}
