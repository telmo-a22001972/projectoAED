package pt.ulusofona.aed.deisiRockstar2021;


public class Artista {
    String ID;
    String Nome;

    Artista(String ID, String Nome) {
        this.ID = ID;
        this.Nome = Nome;
    }
    Artista(){

    }
    public String toString(){
        return ID+" | "+Nome;
    }
}
