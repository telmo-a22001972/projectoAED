package pt.ulusofona.aed.deisiRockstar2021;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class testeCopyArray {
    public static void main(String[] args) {

        ArrayList<Song> teste6 = new ArrayList<Song>();
        Song song1 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,2,false,1,1,1,1);
        teste6.add(song1);
        ArrayList<Song> testeCopy =(ArrayList<Song>) teste6.clone();
        System.out.println(teste6.toString());
        System.out.println(testeCopy.toString());
        teste6.clear();
        testeCopy = (ArrayList<Song>) teste6.clone();
        System.out.println(testeCopy.toString());


    }
}
