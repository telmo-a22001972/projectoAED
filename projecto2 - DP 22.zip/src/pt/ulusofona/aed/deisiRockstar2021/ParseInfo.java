package pt.ulusofona.aed.deisiRockstar2021;

public class ParseInfo {
    int num_Linhas_Ok;
    int num_Linhas_Ignored;

    ParseInfo(int NUM_LINHAS_OK, int NUM_LINHAS_IGNORED) {
        this.num_Linhas_Ok = NUM_LINHAS_OK;
        this.num_Linhas_Ignored = NUM_LINHAS_IGNORED;
    }
    ParseInfo() {

    }

    public String toString() {
        return "OK: "+num_Linhas_Ok+", Ignored: "+num_Linhas_Ignored;
    }
}
