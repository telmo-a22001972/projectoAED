package pt.ulusofona.aed.deisiRockstar2021;

public class ParseInfo {
    int num_Linhas_Ok;
    int num_Linhas_Ignored;

    ParseInfo(int NUM_LINHAS_OK, int NUM_LINHAS_IGNORED) {
        this.num_Linhas_Ok = NUM_LINHAS_OK;
        this.num_Linhas_Ignored = NUM_LINHAS_IGNORED;
    }
    ParseInfo() {

    }


    public String toString() {
        return "OK: "+num_Linhas_Ok+", Ignored: "+num_Linhas_Ignored;
    }

    public ParseInfo (ParseInfo copiado) {
        this.num_Linhas_Ok = copiado.num_Linhas_Ok;
        this.num_Linhas_Ignored = copiado.num_Linhas_Ignored;
    }

    public void reset() {
        this.num_Linhas_Ok = 0;
        this.num_Linhas_Ignored = 0;
    }

}

