
package pt.ulusofona.aed.deisiRockstar2021;
import java.io.IOException;
import java.util.Objects;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

public class Main {
    public static ArrayList < Song > teste6 = new ArrayList < > ();
    public static ArrayList < Song > getSongsArray = new ArrayList < > ();
    public static ArrayList < Artista > testeSongArtists = new ArrayList < > ();
    public static ParseInfo parseInfoSongsTxT = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsArtistsTxT = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsDetailsTxT = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsTxTFinal = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsArtistsTxTFinal = new ParseInfo(0, 0);
    public static ParseInfo parseInfoSongsDetailsTxTFinal = new ParseInfo(0, 0);

    public static void main(String[] args) throws IOException {
        ArrayList < Song > teste7 = new ArrayList < Song > ();
        loadFiles();
        teste7 = getSongs();
        ParseInfo teste8 = getParseInfo("songs.txt");
        System.out.println("\n----------------------TESTE DO MAIN----------------------");
        //System.out.println(teste7.toString());
        //System.out.println(teste8.toString());
        //System.out.println(getSongsArray.size());
        //System.out.println(parseInfoSongsTxTFinal.toString());

    }

    public static void loadFiles() throws IOException {
        //Aqui lê-se o ficheiro songs.txt
        //System.out.println("----------------------LEITURA DO FICHEIRO songs.txt------------");
        String nomeFicheiro = "songs.txt";
        try {
            File ficheiro = new File(nomeFicheiro);
            FileInputStream fis = new FileInputStream(ficheiro);
            Scanner leitorFicheiro = new Scanner(fis);
            while (leitorFicheiro.hasNextLine()) {
                String linha = leitorFicheiro.nextLine();
                String dados[] = linha.split(" @ ");

                if (dados.length != 3) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }

                for (int count = 0; count < dados.length; count++ ) {
                    dados[0].trim();
                    if (dados[count].isEmpty()){
                        parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    }
                }

                if (Character.isWhitespace(dados[2].charAt(0))) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }

                String idTemaMusical = dados[0];
                String nome = dados[1];

                if (nome.charAt(0) < 48 || (nome.charAt(0) > 58 && nome.charAt(0) <65) || (nome.charAt(0) > 90 && nome.charAt(0) <97) || nome.charAt(0) > 122 ){
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (nome.charAt(nome.length()-1) < 48 || (nome.charAt(nome.length()-1) > 58 && nome.charAt(nome.length()-1) <65) || (nome.charAt(nome.length()-1) > 90 && nome.charAt(nome.length()-1) <97) || nome.charAt(nome.length()-1) > 122 ){
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (idTemaMusical.charAt(0) < 48 || (idTemaMusical.charAt(0) > 58 && idTemaMusical.charAt(0) <65) || (idTemaMusical.charAt(0) > 90 && idTemaMusical.charAt(0) <97) || idTemaMusical.charAt(0) > 122 ){
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (idTemaMusical.charAt(idTemaMusical.length()-1) < 48 || (idTemaMusical.charAt(idTemaMusical.length()-1) > 58 && idTemaMusical.charAt(idTemaMusical.length()-1) <65) || (idTemaMusical.charAt(idTemaMusical.length()-1) > 90 && idTemaMusical.charAt(idTemaMusical.length()-1) <97) || idTemaMusical.charAt(idTemaMusical.length()-1) > 122 ){
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }

                int anoLancamento = Integer.parseInt(dados[2]);
                if (anoLancamento<0 || anoLancamento >2021) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                parseInfoSongsTxT.num_Linhas_Ok += 1;

                Song song = new Song(idTemaMusical, nome, null, anoLancamento, 0, false, 0, 0, 0, 0);
                teste6.add(song);
            }
            leitorFicheiro.close();
            getSongsArray = (ArrayList < Song >) teste6.clone();
            teste6.clear();
            parseInfoSongsTxTFinal = new ParseInfo(parseInfoSongsTxT);
            parseInfoSongsTxT.reset();
            System.out.println(parseInfoSongsTxTFinal.toString());

        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + nomeFicheiro + " nao foi encontrado.";
            System.out.println(mensagem);
        }
        //System.out.println(teste6.toString());
        //System.out.println("Ok: " + parseInfoSongsTxT.num_Linhas_Ok + ", Ignored: " + parseInfoSongsTxT.num_Linhas_Ignored + "\n");
        //System.out.println("----------------------LEITURA DO FICHEIRO song_artists.txt------------");
        //Aqui é lido o ficheiro song_artists.txt, mas falta ver se é preciso separar vários artistas com o mesmo ID para posições diferentes no ArrayList
        String nomeFicheiro2 = "song_artists.txt";
        try {
            File song_artists = new File(nomeFicheiro2);
            FileInputStream fis2 = new FileInputStream(song_artists);
            Scanner leitorFicheiro2 = new Scanner(fis2);
            while (leitorFicheiro2.hasNextLine()) {
                String linha = leitorFicheiro2.nextLine();
                String dados[] = linha.split(" @ ");
                if (dados.length != 2) {
                    parseInfoSongsArtistsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[0].charAt(0))) {
                    parseInfoSongsArtistsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[1].charAt(0))) {
                    parseInfoSongsArtistsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                String idTemaMusical = dados[0];
                String artista = dados[1];
                if (artista.charAt(0) != '['){
                    parseInfoSongsArtistsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (artista.charAt(1) != 39){
                    parseInfoSongsArtistsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (artista.charAt(artista.length() - 2) != 39) {
                    parseInfoSongsArtistsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (artista.charAt(artista.length() - 1) != 93) {
                    parseInfoSongsArtistsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                parseInfoSongsArtistsTxT.num_Linhas_Ok += 1;

                Artista artista2 = new Artista(idTemaMusical, artista);
                testeSongArtists.add(artista2);
            }
            leitorFicheiro2.close();
            parseInfoSongsArtistsTxTFinal = new ParseInfo(parseInfoSongsArtistsTxT);
            parseInfoSongsArtistsTxT.reset();
            //System.out.println(parseInfoSongsArtistsTxTFinal.toString());

        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + nomeFicheiro2 + " não foi encontrado.";
            //System.out.println(mensagem);
        }
        //System.out.println(testeSongArtists.toString());
        //System.out.println("Ok: " + parseInfoSongsArtistsTxT.num_Linhas_Ok + ", Ignored: " + parseInfoSongsArtistsTxT.num_Linhas_Ignored + "\n");
        //System.out.println("----------------------LEITURA DO FICHEIRO song_details.txt------------");
        //Aqui lê-se o ficheiro song_details.txt
        boolean letra = false;
        ArrayList < Song > testeSongDetails = new ArrayList < Song > ();
        String nomeFicheiro3 = "song_details.txt";
        try {
            File song_details = new File(nomeFicheiro3);
            FileInputStream fis3 = new FileInputStream(song_details);
            Scanner leitorFicheiro3 = new Scanner(fis3);
            while (leitorFicheiro3.hasNextLine()) {
                String linha = leitorFicheiro3.nextLine();
                String dados[] = linha.split(" @ ");
                if (dados.length != 7) {
                    parseInfoSongsDetailsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[0].charAt(0))) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[1].charAt(0))) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[3].charAt(0))) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[4].charAt(0))) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[5].charAt(0))) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                if (Character.isWhitespace(dados[6].charAt(0))) {
                    parseInfoSongsTxT.num_Linhas_Ignored += 1;
                    continue;
                }
                parseInfoSongsDetailsTxT.num_Linhas_Ok += 1;
                String idTemaMusical = dados[0];
                //System.out.println(idTemaMusical);
                int duracao = Integer.parseInt(dados[1]);
                //System.out.println(duracao);
                int letraExplicita = Integer.parseInt(dados[2]);
                //System.out.println(letraExplicita);
                if (letraExplicita == 0) {
                    letra = false;
                } else {
                    letra = true;
                }
                //System.out.println(letra);
                int populariedade = Integer.parseInt(dados[3]);
                //System.out.println(populariedade);
                double dancabilidade = Double.parseDouble(dados[4]);
                //System.out.println(dancabilidade);
                double vivacidade = Double.parseDouble(dados[5]);
                //System.out.println(vivacidade);
                double volumeMedio = Double.parseDouble(dados[6]);
                //System.out.println(volumeMedio);
                Song song = new Song(idTemaMusical, null, null, 0, duracao, letra, populariedade, dancabilidade, vivacidade, volumeMedio);
                testeSongDetails.add(song);
            }
            leitorFicheiro3.close();
            parseInfoSongsDetailsTxTFinal = new ParseInfo(parseInfoSongsDetailsTxT);
            //System.out.println(parseInfoSongsDetailsTxTFinal.toString());
            parseInfoSongsDetailsTxT.reset();
        } catch (FileNotFoundException exception) {
            String mensagem = "Erro: o ficheiro " + nomeFicheiro3 + " não foi encontrado.";
            //System.out.println(mensagem);
        }
        //System.out.println("Ok: " + parseInfoSongsDetailsTxT.num_Linhas_Ok + ", Ignored: " + parseInfoSongsDetailsTxT.num_Linhas_Ignored);
    }

    public static ArrayList < Song > getSongs() {
        return getSongsArray;
    }

    public static ParseInfo getParseInfo(String fileName) {
        if (Objects.equals(fileName, "songs.txt")) {
            return parseInfoSongsTxTFinal;
        }
        if (Objects.equals(fileName, "song_artists.txt")) {
            return parseInfoSongsArtistsTxTFinal;
        }
        if (Objects.equals(fileName, "song_details.txt")) {
            return parseInfoSongsDetailsTxTFinal;
        }
        return null;
    }
}