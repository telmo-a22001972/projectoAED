package pt.ulusofona.aed.deisiRockstar2021;

import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;


public class TestXXX {

    public static void main(String[] args) {

    }
    @Test
    public void testGetSongToString3Musicas() throws IOException {
        //Song song1 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
        Song song2 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottles",null,1979,0,false,0,0,0,0);
        //Song song3 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
        //ArrayList<Song> testeSongs = new ArrayList<Song>();
        //testeSongs.add(song1);
        //testeSongs.add(song2);
        //testeSongs.add(song3);
        //String resultadoReal = testeSongs.toString();
        //String resultadoEsperado = "[1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979, 1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979, 1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979]";
        Assert.assertEquals("1oYYd2gnWZYrt89EBXdFiO | Message In A Bottles | 1979",song2.toString());

    }
    @Test
    public void testGetSongToString2Musicas() throws IOException {
        Song song1 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
        //Song song2 = new Song("1oYYd2gnWZYrt89EBXdFiO","Message In A Bottle",null,1979,0,false,0,0,0,0);
        //ArrayList<Song> testeSongs = new ArrayList<Song>();
        //testeSongs.add(song1);
        //testeSongs.add(song2);
        //String resultadoReal = testeSongs.toString();
        //String resultadoEsperado = "[1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979, 1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979]";
        Assert.assertEquals("1oYYd2gnWZYrt89EBXdFiO | Message In A Bottle | 1979",song1.toString());
    }
    @Test
    public void testTamanhoArrayMusicas() throws IOException {
        Main.loadFiles();
        Main.getSongs();
        int resultadoReal = Main.getSongs().size();
        Assert.assertEquals(2,resultadoReal);

    }

}
